 <div id="cclw_payment_section">
   <?php  woocommerce_checkout_payment(); ?>
 </div>